# gcb-android-tutorial
A random Android Project for utilizinng Google Cloud Build for Android Gradle

### [Awesome Cloud Build](https://github.com/Timtech4u/awesome-cloudbuild)
